import React from 'react'
import { Signup as SignupComponent } from '../Components'

function Signup() {
  return (
    <div className='py-8'>
        <SignupComponent />
    </div>
  )
}

export default Signup